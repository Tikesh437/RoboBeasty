package com.robocar.control;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private String base = "http://192.168.4.1";
    private TextView connection, distance, waterState, voiceResult;
    private EditText ipInput, commandInput;
    private WebView camera;
    private final Handler handler = new Handler();
    private final Handler driveHandler = new Handler();
    private final Handler fireHandler = new Handler();
    private final ExecutorService commandQueue = Executors.newSingleThreadExecutor();
    private boolean cameraOn = true;
    private Runnable driveRepeat;
    private boolean flash = false;
    private int water = 0;
    private static final int VOICE_REQUEST = 501;

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(12),dp(8),dp(12),dp(12)); return l; }
    private TextView text(String s, int size) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(235,240,248)); t.setPadding(0,dp(5),0,dp(5)); return t; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    private void add(LinearLayout p, View v) { p.addView(v, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); }
    private LinearLayout row(LinearLayout p) { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER); r.setWeightSum(3); p.addView(r); return r; }
    private void cell(LinearLayout r, View v) { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1); lp.setMargins(dp(3),dp(2),dp(3),dp(2)); r.addView(v,lp); }
    private void section(LinearLayout p, String name) { TextView h=text(name,18); h.setTextColor(Color.rgb(120,195,255)); h.setPadding(0,dp(14),0,dp(4)); add(p,h); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.rgb(13,19,30));
        buildUi();
        handler.post(statusPoll);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(Color.rgb(13,19,30));
        LinearLayout root = column(); root.setBackgroundColor(Color.rgb(13,19,30)); scroll.addView(root);
        setContentView(scroll);
        TextView title=text("ROBOCAR  /  CONTROL CENTER",22); title.setGravity(Gravity.CENTER); title.setPadding(0,dp(12),0,dp(8)); add(root,title);
        connection=text("Not connected — join Wi-Fi RoboCar first",14); connection.setTextColor(Color.YELLOW); add(root,connection);
        LinearLayout iprow=row(root); ipInput=new EditText(this); ipInput.setSingleLine(true); ipInput.setText(base.replace("http://","")); ipInput.setHint("ESP32-CAM IP"); ipInput.setTextColor(Color.WHITE); ipInput.setHintTextColor(Color.GRAY); cell(iprow,ipInput); Button connect=button("Connect"); cell(iprow,connect); connect.setOnClickListener(v->{String host=ipInput.getText().toString().trim(); if(!host.isEmpty()){base="http://"+host; loadCamera(); checkStatus();}});

        section(root,"LIVE CAMERA");
        camera=new WebView(this); camera.setBackgroundColor(Color.BLACK); camera.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(210)));
        WebSettings ws=camera.getSettings(); ws.setJavaScriptEnabled(false); ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); camera.loadDataWithBaseURL(base,"<html><body style='margin:0;background:#000'><img style='width:100%;height:auto' src='"+base+":81/stream'></body></html>","text/html","UTF-8",null); add(root,camera);
        LinearLayout camrow=row(root); Button camReload=button("Camera: ON / OFF"); cell(camrow,camReload); Button flashBtn=button("Flash ON / OFF"); cell(camrow,flashBtn); camReload.setOnClickListener(v->{cameraOn=!cameraOn;if(cameraOn)loadCamera();else camera.loadData("<html><body style='background:#000;color:white'>Camera paused</body></html>","text/html","UTF-8");camReload.setText(cameraOn?"Camera: ON":"Camera: OFF");}); flashBtn.setOnClickListener(v->{flash=!flash; send("/flash?s="+(flash?1:0)); flashBtn.setText(flash?"Flash: ON":"Flash: OFF");});

        section(root,"DRIVE MODES"); LinearLayout modes=row(root);
        String[] modeNames={"Manual","Avoid","Hand","Line"};
        for(int i=0;i<4;i++){ final int m=i+1; Button b=button(modeNames[i]); cell(modes,b); b.setOnClickListener(v->send("/mode?m="+m)); }
        section(root,"MANUAL DRIVE  ·  HOLD TO MOVE");
        LinearLayout r1=row(root); cell(r1,new TextView(this)); Button forward=button("▲"); cell(r1,forward); cell(r1,new TextView(this)); driveButton(forward,'F');
        LinearLayout r2=row(root); Button left=button("◀"); cell(r2,left); Button stop=button("■  STOP"); cell(r2,stop); Button right=button("▶"); cell(r2,right); driveButton(left,'L'); driveButton(right,'R'); stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(190,40,45))); stop.setTextColor(Color.WHITE); stop.setOnClickListener(v->stopDrive());
        LinearLayout r3=row(root); cell(r3,new TextView(this)); Button back=button("▼"); cell(r3,back); cell(r3,new TextView(this)); driveButton(back,'B');
        section(root,"SPEED"); SeekBar speed=new SeekBar(this); speed.setMax(155); speed.setProgress(100); add(root,speed); TextView speedLabel=text("Speed: 200 / 255",13); add(root,speedLabel); speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){int val=p+100;speedLabel.setText("Speed: "+val+" / 255");if(u)send("/speed?v="+val);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){send("/speed?v="+(s.getProgress()+100));}});

        section(root,"VOICE COMMANDS  /  आवाज़ से नियंत्रण");
        commandInput=new EditText(this); commandInput.setSingleLine(true); commandInput.setHint("Type or use Gboard mic: forward / आगे"); commandInput.setTextColor(Color.WHITE); commandInput.setHintTextColor(Color.GRAY); add(root,commandInput);
        LinearLayout vr=row(root); Button voice=button("🎤 Speak"); cell(vr,voice); Button execute=button("Send command"); cell(vr,execute); voiceResult=text("Voice ready. Say a short command.",13); add(root,voiceResult);
        voice.setOnClickListener(v->startVoice()); execute.setOnClickListener(v->processVoice(commandInput.getText().toString()));

        section(root,"ROBOTIC ARM  /  SERVO CONTROLS");
        addServo(root,"Camera Pan",0,0,180,90); addServo(root,"Camera Tilt",1,30,150,90);
        addServo(root,"Arm Base",2,0,180,90); addServo(root,"Arm Shoulder",3,40,150,90); addServo(root,"Gripper",4,20,100,20);
        addServo(root,"Fire attachment (momentary)",5,30,150,90);
        LinearLayout presets=row(root); String[] pn={"Home","Reach","Carry"}; for(int i=0;i<3;i++){final int n=i;Button b=button(pn[i]);cell(presets,b);b.setOnClickListener(v->send("/preset?n="+n));}
        LinearLayout grip=row(root); Button go=button("Gripper OPEN");cell(grip,go);Button gc=button("Gripper CLOSE");cell(grip,gc);go.setOnClickListener(v->send("/grip?s=open"));gc.setOnClickListener(v->send("/grip?s=close"));
        Button fire=button("Hold FIRE actuator");add(root,fire);fire.setOnTouchListener((v,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){fireHandler.removeCallbacksAndMessages(null);send("/servo?i=5&a=120");return true;}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){fireHandler.postDelayed(()->send("/servo?i=5&a=90"),700);return true;}return true;});

        section(root,"AMPHIBIOUS FLOATS"); waterState=text("Floats: status unknown",14); add(root,waterState);
        LinearLayout wr=row(root); Button deploy=button("WATER DEPLOY");cell(wr,deploy);Button retract=button("WATER RETRACT");cell(wr,retract);
        deploy.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Deploy side floats?").setMessage("The robot will stop and request float deployment. Check both mechanical locks manually. Status cannot verify latch engagement.").setNegativeButton("Cancel",null).setPositiveButton("Deploy",(d,w)->send("/water?a=D")).show());
        retract.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Retract side floats?").setMessage("Retract only when safe. Check the physical float positions and latches manually.").setNegativeButton("Cancel",null).setPositiveButton("Retract",(d,w)->send("/water?a=R")).show());
        section(root,"SYSTEM STATUS"); distance=text("Distance: —",14);add(root,distance); Button refresh=button("Refresh status");add(root,refresh);refresh.setOnClickListener(v->checkStatus());
        TextView note=text("Safety: drive buttons work in Manual mode. Releasing a drive button sends STOP. Float status reports commanded servo travel, not confirmed mechanical lock position. Test with wheels lifted before normal operation.",12); note.setTextColor(Color.LTGRAY);add(root,note);
    }

    private void addServo(LinearLayout root,String name,int index,int min,int max,int initial){
        TextView label=text(name+"  ·  CH"+index,14);add(root,label);SeekBar bar=new SeekBar(this);bar.setMax(max-min);bar.setProgress(initial-min);add(root,bar);
        final Handler throttle=new Handler(); final int[] last={-1}; final Runnable[] pending={null};
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){int a=p+min;label.setText(name+"  ·  CH"+index+"  ·  "+a+"°");if(user){if(pending[0]!=null)throttle.removeCallbacks(pending[0]);pending[0]=()->send("/servo?i="+index+"&a="+a);throttle.postDelayed(pending[0],90);}}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){send("/servo?i="+index+"&a="+(s.getProgress()+min));}});
    }

    private void driveButton(Button b,char direction){
        b.setOnTouchListener((v,e)->{
            if(e.getAction()==MotionEvent.ACTION_DOWN){send("/cmd?d="+direction);if(driveRepeat!=null)driveHandler.removeCallbacks(driveRepeat);driveRepeat=new Runnable(){public void run(){send("/cmd?d="+direction);driveHandler.postDelayed(this,150);}};driveHandler.postDelayed(driveRepeat,150);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){stopDrive();return true;}return true;
        });
    }
    private void stopDrive(){if(driveRepeat!=null)driveHandler.removeCallbacks(driveRepeat);driveRepeat=null;send("/cmd?d=S");}
    private void loadCamera(){if(camera!=null)camera.loadDataWithBaseURL(base,"<html><body style='margin:0;background:#000'><img style='width:100%;height:auto' src='"+base+":81/stream'></body></html>","text/html","UTF-8",null);}
    private void send(String path){final String url=base+path;commandQueue.execute(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(1600);c.setReadTimeout(1600);c.setRequestMethod("GET");c.getInputStream().close();}catch(Exception ignored){}finally{if(c!=null)c.disconnect();}});}
    private JSONObject getStatus() throws Exception {HttpURLConnection c=(HttpURLConnection)new URL(base+"/status").openConnection();c.setConnectTimeout(1800);c.setReadTimeout(1800);InputStream in=c.getInputStream();BufferedReader br=new BufferedReader(new InputStreamReader(in));StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);br.close();c.disconnect();return new JSONObject(sb.toString());}
    private void checkStatus(){new Thread(()->{try{JSONObject j=getStatus();runOnUiThread(()->applyStatus(j));}catch(Exception e){runOnUiThread(()->connection.setText("Not connected — connect to RoboCar Wi-Fi and retry"));}}).start();}
    private void applyStatus(JSONObject j){boolean link=j.optInt("link",0)==1;connection.setText(link?"ESP32-CAM connected  ·  DevKit link OK":"ESP32-CAM reachable  ·  DevKit link LOST");connection.setTextColor(link?Color.GREEN:Color.RED);distance.setText("Mode: "+new String[]{"?","Manual","Obstacle Avoidance","Hand Following","Line Following"}[Math.max(0,Math.min(4,j.optInt("mode",0)))]+"   |   Distance: "+j.optInt("dist",-1)+" cm");water=j.optInt("w",0);String[] states={"Folded","Deploying","Deployed — check mechanical locks","Retracting"};waterState.setText("Floats: "+states[Math.max(0,Math.min(3,water))]);flash=j.optInt("flash",0)==1;}
    private final Runnable statusPoll=new Runnable(){public void run(){checkStatus();handler.postDelayed(this,2000);}};

    private void startVoice(){new AlertDialog.Builder(this).setTitle("Choose voice language").setItems(new String[]{"English (India)","हिन्दी"},(d,which)->{try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,which==0?"en-IN":"hi-IN");i.putExtra(RecognizerIntent.EXTRA_PROMPT,which==0?"Say a RoboCar command":"रोबोकार का आदेश बोलें");startActivityForResult(i,VOICE_REQUEST);}catch(Exception e){Toast.makeText(this,"Speech input is unavailable. Use the Gboard microphone in the text box.",Toast.LENGTH_LONG).show();}}).show();}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==VOICE_REQUEST&&resultCode==RESULT_OK&&data!=null){ArrayList<String> r=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(r!=null&&!r.isEmpty()){commandInput.setText(r.get(0));processVoice(r.get(0));}}}
    private void processVoice(String raw){String s=raw.toLowerCase(Locale.ROOT).trim();voiceResult.setText("Heard: "+raw);if(s.contains("stop")||s.contains("रुको")||s.contains("बंद")){stopDrive();return;}
        if(s.contains("forward")||s.contains("आगे")||s.contains("चलो")){send("/mode?m=1");send("/cmd?d=F");new Handler().postDelayed(this::stopDrive,1100);return;}
        if(s.contains("back")||s.contains("reverse")||s.contains("पीछे")){send("/mode?m=1");send("/cmd?d=B");new Handler().postDelayed(this::stopDrive,1100);return;}
        if(s.contains("left")||s.contains("बाएं")||s.contains("बायें")){send("/mode?m=1");send("/cmd?d=L");new Handler().postDelayed(this::stopDrive,1100);return;}
        if(s.contains("right")||s.contains("दाएं")||s.contains("दायें")){send("/mode?m=1");send("/cmd?d=R");new Handler().postDelayed(this::stopDrive,1100);return;}
        if(s.contains("deploy")||s.contains("तैर")||s.contains("फ्लोट खोल")){new AlertDialog.Builder(this).setMessage("Request float deployment? Verify locks manually.").setNegativeButton("Cancel",null).setPositiveButton("Deploy",(d,w)->send("/water?a=D")).show();return;}
        if(s.contains("retract")||s.contains("fold")||s.contains("फ्लोट बंद")){send("/water?a=R");return;}
        if(s.contains("open gripper")||s.contains("ग्रिपर खोल")){send("/grip?s=open");return;}
        if(s.contains("close gripper")||s.contains("ग्रिपर बंद")){send("/grip?s=close");return;}
        if(s.contains("home")||s.contains("घर")){send("/preset?n=0");return;}
        if(s.contains("reach")){send("/preset?n=1");return;}if(s.contains("carry")){send("/preset?n=2");return;}
        voiceResult.setText("Command not recognized. Try forward, left, stop, open gripper, or use the controls.");
    }
    @Override protected void onPause(){super.onPause();stopDrive();}
    @Override protected void onDestroy(){handler.removeCallbacks(statusPoll);driveHandler.removeCallbacksAndMessages(null);fireHandler.removeCallbacksAndMessages(null);commandQueue.shutdownNow();if(camera!=null)camera.destroy();super.onDestroy();}
}
