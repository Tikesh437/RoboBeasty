# RoboCar Control Center (Android)

Native Android app project for the existing RoboCar firmware. It uses the ESP32-CAM HTTP endpoints and camera stream; it does not replace either ESP32 sketch or change the ESP32-CAM ↔ ESP32 DevKit UART architecture.

## Existing hardware / firmware retained
- ESP32-CAM AP: `RoboCar` / `robocar123`, default address `192.168.4.1`
- Camera stream: `http://192.168.4.1:81/stream`
- ESP32-CAM status: `/status`
- L298N drive: `/cmd?d=F|B|L|R|S`; modes `/mode?m=1..4`; speed `/speed?v=100..255`
- PCA9685 channels 0–7: pan, tilt, base, shoulder, gripper, fire, left float, right float
- Arm presets `/preset?n=0..2`; gripper `/grip?s=open|close`; floats `/water?a=D|R`; flash `/flash?s=0|1`
- The app reads the existing JSON status including mode, distance, link, flash, water state and servo angles.

## Build an APK in GitHub Actions
1. Create a GitHub repository named `RoboCarControlCenter`.
2. Upload the contents of this folder to the repository root (not the folder itself).
3. Open the repository's **Actions** tab and run **Build RoboCar APK** (or push to `main`).
4. Open the completed workflow run and download the artifact named `RoboCar-Control-Center-debug`.
5. Extract the ZIP and install `app-debug.apk` on Android. Approve Android's install-from-this-source prompt if shown.

The build uses Java 17, Gradle 8.7 and Android Gradle Plugin 8.6.1.

## Phone setup
1. Power on both controller boards and connect the phone to Wi-Fi `RoboCar` (password `robocar123`).
2. Android may warn that this Wi-Fi has no internet. Choose to stay connected.
3. Open the app; the default ESP32-CAM address is `192.168.4.1`. Tap Connect.
4. Test status and camera first, then test drive with the wheels lifted and STOP immediately after each direction test.

## Voice
The Speak button uses Android's installed speech-recognition service. For Gboard voice typing, tap the command field, use the keyboard microphone, then tap Send command. Speech recognition may require internet depending on the installed Android speech service and language pack.

## Safety / limitations
- The app does not add a physical emergency stop; the on-screen STOP is a software command.
- Drive buttons send repeated commands while held and send STOP on release; the DevKit's own manual-drive watchdog remains active.
- The firmware reports float servo travel commands, not physical latch engagement. Check mechanical locks manually.
- Voice movement commands are short 1.1-second pulses. Test at low speed with wheels lifted.
- This source project has not been compiled or hardware-tested in this environment. Build via Actions and bench-test before operating the robot.
